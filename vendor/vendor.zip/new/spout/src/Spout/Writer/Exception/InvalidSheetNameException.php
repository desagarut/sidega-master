<?php

namespace Box\Spout\Writer\Exception;

/**
 * Class InvalidSheetNameException
 */
class InvalidSheetNameException extends WriterException
{
}
